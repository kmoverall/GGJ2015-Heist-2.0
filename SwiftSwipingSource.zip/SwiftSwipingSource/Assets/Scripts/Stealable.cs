﻿using UnityEngine;
using System.Collections;

public interface Stealable {
    int Steal(Player culprit);
}
